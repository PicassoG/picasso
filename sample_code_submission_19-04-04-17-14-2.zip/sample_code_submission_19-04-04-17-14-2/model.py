'''
Sample predictive model.
You must supply at least 4 methods:
- fit: trains the model.
- predict: uses the model to perform predictions.
- save: saves the model.
- load: reloads the model.
'''
import pickle
import numpy as np   # We recommend to use numpy arrays
from os.path import isfile
from sklearn.base import BaseEstimator
from sklearn import tree
from sklearn.neural_network import MLPClassifier  # Choix de notre classifieur

from sklearn import linear_model
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC

from sklearn.metrics import make_scorer
from sklearn.model_selection import cross_val_score
'''
problem_dir = 'ingestion_program/'  
score_dir = 'scoring_program/'
from sys import path; path.append(problem_dir); path.append(score_dir); 


from libscores import get_metric		#Je n'arrive pas a importer les classes
from data_manager import DataManager
'''

class model (BaseEstimator):
    def __init__(self):
        '''
        This constructor is supposed to initialize data members.
        Use triple quotes for function documentation. 
        '''
        self.num_train_samples=0
        self.num_feat=1
        self.num_labels=1
        self.is_trained=False
        self.model = clf = MLPClassifier() #Initilize le classifieur choisi

        
    def fit(self, X, y):
        '''
        This function should train the model parameters.
        Here we do nothing in this example...
        Args:
            X: Training data matrix of dim num_train_samples * num_feat.
            y: Training label matrix of dim num_train_samples * num_labels.
        Both inputs are numpy arrays.
        For classification, labels could be either numbers 0, 1, ... c-1 for c classe
        or one-hot encoded vector of zeros, with a 1 at the kth position for class k.
        The AutoML format support on-hot encoding, which also works for multi-labels problems.
        Use data_converter.convert_to_num() to convert to the category number format.
        For regression, labels are continuous values.
        '''
        self.num_train_samples = X.shape[0]
        if X.ndim>1: self.num_feat = X.shape[1]
        print("FIT: dim(X)= [{:d}, {:d}]".format(self.num_train_samples, self.num_feat))
        num_train_samples = y.shape[0]
        if y.ndim>1: self.num_labels = y.shape[1]
        print("FIT: dim(y)= [{:d}, {:d}]".format(num_train_samples, self.num_labels))
        if (self.num_train_samples != num_train_samples):
            print("ARRGH: number of samples in X and y do not match!")
        self.is_trained=True
        print('Debut du training du modele')
        self.model = self.model.fit(X, y)
        print('Fin du training du modele')

    def predict(self, X):
        '''
        This function should provide predictions of labels on (test) data.
        Here we just return zeros...
        Make sure that the predicted values are in the correct format for the scoring
        metric. For example, binary classification problems often expect predictions
        in the form of a discriminant value (if the area under the ROC curve it the metric)
        rather that predictions of the class labels themselves. For multi-class or multi-labels
        problems, class probabilities are often expected if the metric is cross-entropy.
        Scikit-learn also has a function predict-proba, we do not require it.
        The function predict eventually can return probabilities.
        '''
        num_test_samples = X.shape[0]
        if X.ndim>1: num_feat = X.shape[1]
        print("PREDICT: dim(X)= [{:d}, {:d}]".format(num_test_samples, num_feat))
        if (self.num_feat != num_feat):
            print("ARRGH: number of features in X does not match training data!")
        print("PREDICT: dim(y)= [{:d}, {:d}]".format(num_test_samples, self.num_labels))
        y = self.model.predict_proba(X)
        # If you uncomment the next line, you get pretty good results for the Iris data :-)
        #y = np.round(X[:,3])
        return y[:,1]

    def save(self, path="./"):
        pickle.dump(self.model, open(path + '_model.pickle', "wb"))

    def load(self, path="./"):
        modelfile = path + '_model.pickle'
        if isfile(modelfile):
            with open(modelfile, 'rb') as f:
                self = pickle.load(f)
            print("Model reloaded from: " + modelfile)
        return self
        '''
        Prend en parametre un tableau de flottant et renvoie l'indice avec la valeur la plus grande
        '''
    def max_tableauCVScore(tab):		#Calcul indice du maximum
        if len(tab) == 0 :
            return -1
        if len(tab) == 1 :
            return 0
        best = tab[0]
        bestIndice = 0
        for i in range(len(tab)) :
            if best < tab[i] :
                best = tab[i]
                bestIndice = i
        print("CV Score : ", best)
        return bestIndice
		    

#        Parmi une liste de classifieur, renvoie le meilleur pour une base de donnees donnees
#        param X_train : les donnees d apprentissage
#        param Y_train : les labels de ces donnees
#        param listModel : une liste contenant differentes modele de classifieur
#        return l indice du meilleur classifieur

    def calculBest_CVScore(X_train,Y_train,listModel):		#Calcul les score CV de tous les models puis renvoie l indice du meilleur score.mean
        tabScore = []
        metric_name, scoring_function = get_metric()
        for i in range(len(listModel)) :
                score = cross_val_score(listModel[i], X_train, Y_train, cv=5, scoring=make_scorer(scoring_function))
                tabScore.append(score.mean)
        return max_tableauCVScore(tabScore)
	
    if __name__ == "__main__" :
        '''
        #On charge les donnees
        data_dir = '../../public_data'         
        data_name = 'perso'
        D = DataManager(data_name, data_dir, replace_missing=True)
        X = D.data['X_train']
        Y = D.data['Y_train'] 
          
        listModel = [MLPClassifier(),linear_model.SGDClassifier(),LogisticRegression(),tree.DecisionTreeClassifier(),RandomForestClassifier(),GaussianNB()] #Liste des classifieurs a tester
        listNomModel = ["MLPClassifier","SGDCClassifier","LogisticRegression","DecisionTreeClassifier","RandomForestClassifier","GaussianNB"] #Dans le meme ordre le nom de ces classifieurs
        indiceBestModel = calculBest_CVScore(X,Y,listModel)
        BestModel = listNomModel[indiceBestModel]
        print("Best model is ", BestModel)
        '''

        

	    
	    
	    
