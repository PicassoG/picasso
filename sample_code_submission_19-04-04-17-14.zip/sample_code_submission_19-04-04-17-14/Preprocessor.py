'''
Sample predictive model.
You must supply at least 4 methods:
- fit: trains the model.
- predict: uses the model to perform predictions.
- save: saves the model.
- load: reloads the model.
'''
import pickle
import numpy as np   # We recommend to use numpy arrays
from os.path import isfile
from sklearn.base import BaseEstimator
from sklearn import tree
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import PCA               #model de preprocessing utilisé
from sklearn.feature_selection import SelectKBest
from sklearn.neural_network import MLPClassifier

from sklearn.metrics import make_scorer
from sklearn.model_selection import cross_val_score

#from libscores import get_metric
#from data_manager import DataManager

from data_io import read_as_df

class Preprocessor(BaseEstimator): #VERSION 1
    def __init__(self):
        self.transformer = PCA(n_components=100) #Initialisation du modele de preprocessing
    

    def fit(self, X_train, Y_train):
        return self.transformer.fit(X_train,Y_train) #Training du modele de preprocessing
            
    def fit_transform(self, X, Y):
        print('Donnee ont ete traite')
        return self.transformer.fit_transform(X,Y) # Train le modele et renvoie les donnes preprocesse
    
    def transform(self, X, y=None):
        print('Donnee ont ete traite')
        return self.transformer.transform(X) # renvoie les donnee preprocesse
    
    if __name__=="__main__" :
        '''
        data_dir = '../../public_data'         
        data_name = 'perso'
        D = DataManager(data_name, data_dir, replace_missing=True)  # On importe les data avec datamanager
        X_train = D.data['X_train']
        Y_train = D.data['Y_train']
        P = Preprocessor()                      #On appelle de model de preprocessing
        P.fit(X_train, Y_train)         #fit
        X = P.transform(X_train)            #On met les données préprocessées dans X
        test = "true"
        for i in range(len(X)) :        # TEST SI TOUTE LES VALEURS SONT BIEN DE DIMENSION 100
            if len(X[i]) != 100 :
                test = "false"
        print("Test if every data has 100 component ", test)
        
        metric_name, scoring_function = get_metric()
        
        BestScore = 0.0
        Besti = 0
        
        for i in range(10,190,10) :		#Test quelle est le meilleur hyper parametre pour n_component
            P = PCA(n_components=i)
            Xpp = PCA.fit_transform(X_train)
            model = MLPClassifier()
            score = cross_val_score(listModel[i], X_train, Y_train, cv=5, scoring=make_scorer(scoring_function))
            if score > BestScore :
                BestScore = score
                Besti = i
        print('Best n_components for PCA : ', i)
        '''
